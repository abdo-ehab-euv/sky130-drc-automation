# sky130-drc-automation

A small, beginner-friendly Physical Verification / Design Rule Checking (DRC)
automation project built on the open-source **SKY130** PDK using **KLayout**,
**Python**, and **TCL**.

> ℹ️ This is a **scoped educational project** — four representative rules on
> SKY130 layers — not a full tapeout-grade production deck (like a complete
> Calibre SVRF sign-off deck).

---

## What this project does

Given a GDSII layout file, the project:

1. Runs a custom DRC rule deck in KLayout (batch mode, no GUI).
2. Produces an XML violation report (`results.xml`).
3. Parses the XML and builds:
   - a terminal summary table,
   - a bar chart (`violations.png`),
   - a self-contained HTML dashboard (`drc_report.html`).

## Why DRC matters

Every foundry publishes geometric constraints — minimum widths, spacings,
enclosures, areas, antenna ratios, etc. — that every layout must satisfy in
order to be manufacturable. A single violation can mean the chip fails
lithography or etching, which means the tapeout fails (and a tapeout can cost
millions of dollars). DRC is the automated last line of defence before
fabrication.

## Tool stack

| Tool       | Role                                                 |
|------------|------------------------------------------------------|
| KLayout    | DRC engine (GUI + batch mode)                        |
| Python 3   | Runner + XML parser + report generator               |
| TCL        | Alternate batch wrapper                              |
| SKY130 PDK | Open-source 130 nm process design kit (for layout)   |

## Files in the repo

| File                 | Purpose                                             |
|----------------------|-----------------------------------------------------|
| `drc_rules.lydrc`    | KLayout DRC rule deck (the core deliverable)        |
| `run_drc.py`         | Python wrapper that runs KLayout in batch           |
| `analyze_results.py` | Parses `results.xml` → HTML + PNG + terminal output |
| `run_drc.tcl`        | Equivalent TCL batch wrapper                        |
| `requirements.txt`   | Python dependencies                                 |
| `.gitignore`         | Ignore generated artefacts                          |
| `README.md`          | This file                                           |

## Requirements

- **KLayout 0.29+** — install from <https://www.klayout.de>. The `klayout`
  executable must be on your `PATH` (or you can pass `--klayout /full/path`).
- **Python 3.9+**.
- The Python packages listed in `requirements.txt`.
- A SKY130 GDS file saved as `layout.gds` (e.g. a cell from
  [`sky130_fd_sc_hd`](https://github.com/google/skywater-pdk), or any
  open-source SKY130 chip GDS such as from
  [`efabless/caravel`](https://github.com/efabless/caravel)).

## Setup

```bash
git clone https://github.com/<your-user>/sky130-drc-automation.git
cd sky130-drc-automation

python -m venv .venv
# macOS / Linux:
source .venv/bin/activate
# Windows (PowerShell):
# .venv\Scripts\Activate.ps1

pip install -r requirements.txt
```

Drop your GDSII into the project root as `layout.gds` (or use any filename
and pass it via `--input`).

## How to run DRC

```bash
python run_drc.py --input layout.gds --output results.xml
```

This invokes KLayout under the hood with:

```
klayout -b -r drc_rules.lydrc -rd input=layout.gds -rd output=results.xml
```

and writes `results.xml`.

## How to generate the report

After DRC has run:

```bash
python analyze_results.py --input results.xml --html drc_report.html
```

This produces:

- `drc_report.html` — open in any browser
- `violations.png`  — bar chart of violations per rule
- A terminal summary table

## Combined flow

Run DRC and build the report in one step with the `--analyze` flag:

```bash
python run_drc.py --input layout.gds --output results.xml --analyze
```

## Rules implemented

| Rule ID     | Layer(s)     | Check             | Value        |
|-------------|--------------|-------------------|--------------|
| `LI.W.1`    | `li1`        | Minimum width     | 0.17 µm      |
| `LI.S.1`    | `li1`        | Minimum spacing   | 0.17 µm      |
| `NW.ENC.1`  | `nwell`, `nsdm` | Enclosure      | 0.125 µm     |
| `MCON.A.1`  | `mcon`       | Minimum area      | 0.2025 µm²   |

SKY130 layer/datatype pairs used:
`li1 (67/20)`, `nwell (64/20)`, `nsdm (93/44)`, `mcon (67/44)`.

## Expected outputs

| File               | Description                                  |
|--------------------|----------------------------------------------|
| `results.xml`      | KLayout DRC report database (XML)            |
| `violations.png`   | Bar chart image                              |
| `drc_report.html`  | Self-contained HTML dashboard                |

## Troubleshooting

- **`klayout: command not found`**
  KLayout is not on your `PATH`. Either add it, or pass the full path:
  `python run_drc.py --klayout /Applications/klayout.app/Contents/MacOS/klayout ...`
- **KLayout exits with a non-zero code.**
  Re-run the exact `klayout -b -r ...` command printed by `run_drc.py` to see
  the full log. Usually it is a bad GDS path or a syntax issue in
  `drc_rules.lydrc`.
- **Empty report / no violations.**
  Either the layout is genuinely clean, or the GDS uses different layer numbers
  than the SKY130 mapping in the rule deck. Open the GDS in KLayout and check
  the `Layers` panel.
- **`matplotlib` error on a headless server.**
  The analyzer already forces the `Agg` backend, so no display is needed —
  just make sure matplotlib is installed (`pip install -r requirements.txt`).
- **Coordinates show up as `N/A`.**
  Some KLayout report entries do not include parseable geometry text. The
  parser is intentionally defensive and falls back to `N/A` rather than
  crashing.

## Future improvements

- Expand the rule deck to cover metal1/metal2 widths and spacings, via
  enclosure, poly width, and antenna ratio checks.
- Add an LVS (Layout Versus Schematic) step in KLayout.
- Wire up a GitHub Actions job that runs DRC on every push and posts the
  violation count as a status badge.
- Add performance profiling for very large layouts (tens of thousands of
  violations), and tune the analyzer for those cases.

## How this relates to industry tools

KLayout's DRC scripting is directly analogous to Siemens **Calibre SVRF**:
the geometric primitives (`width`, `space`, `enclosing`, `with_area`) and the
concept of a report database are the same. The workflow — write rule deck →
batch run → parse report → triage violations — is exactly how Calibre is used
in production.

## CV bullet

> Built a SKY130-based Physical Verification mini-project that automates DRC
> end-to-end with KLayout (Python-based rule DSL, analogous to Calibre SVRF),
> a TCL batch wrapper, and a Python analyser that turns KLayout's XML output
> into an HTML dashboard with per-rule status, a violation bar chart, and a
> coordinate-level details table.

## Short interview explanation

"I wrote a small DRC rule deck for the open-source SKY130 PDK — four real
rules covering minimum width, minimum spacing, enclosure, and minimum area on
`li1`, `nwell`, `nsdm`, and `mcon`. I run it in KLayout's batch mode from a
Python wrapper that captures the XML report and feeds it into an analyser,
which produces an HTML dashboard with each rule's status (PASS/FAIL), a bar
chart of violation counts, and a details table with coordinates. It's
scoped — just KLayout and four rules, not a full Calibre sign-off deck — but
the flow (rule deck → batch run → report → triage) is exactly what a PV
engineer does day-to-day."
